// Geofen's : Dice Bag v1.0.0
// Targeted specifically at Dice So Nice! 6.2.9 / Foundry VTT 14.365.

const MODULE_ID = "geofen-s-dice-bag";
const CATEGORY = "Geofen's : Dice Bag";
const FACTIONS = [
  {
    "id": "empire",
    "name": "Empire of Man",
    "bg": "#7B1113",
    "fg": "#F2D675",
    "edge": "#3A0708",
    "material": "metal",
    "pattern": "scratched",
    "motif": "comet"
  },
  {
    "id": "bretonnia",
    "name": "Kingdom of Bretonnia",
    "bg": "#1A4D9B",
    "fg": "#F5E7A4",
    "edge": "#9A7A24",
    "material": "pristine",
    "pattern": "heraldic",
    "motif": "shield"
  },
  {
    "id": "kislev",
    "name": "Kislev",
    "bg": "#D7E5EE",
    "fg": "#1F4F76",
    "edge": "#6E8FA3",
    "material": "frosted",
    "pattern": "frost",
    "motif": "bear"
  },
  {
    "id": "dwarfs",
    "name": "Dwarfen Mountain Holds",
    "bg": "#4C3A2B",
    "fg": "#D8B65A",
    "edge": "#1F1711",
    "material": "stone",
    "pattern": "stone",
    "motif": "hammer"
  },
  {
    "id": "high-elves",
    "name": "High Elf Realms",
    "bg": "#EDE7D4",
    "fg": "#2E6B8C",
    "edge": "#C9A94D",
    "material": "pristine",
    "pattern": "silk",
    "motif": "sun"
  },
  {
    "id": "wood-elves",
    "name": "Wood Elf Realms",
    "bg": "#31563A",
    "fg": "#D6C889",
    "edge": "#182B1D",
    "material": "wood",
    "pattern": "wood",
    "motif": "leaf"
  },
  {
    "id": "dark-elves",
    "name": "Dark Elves",
    "bg": "#2A1538",
    "fg": "#D8C8E8",
    "edge": "#0D0712",
    "material": "metal",
    "pattern": "blade",
    "motif": "crescent"
  },
  {
    "id": "lizardmen",
    "name": "Lizardmen",
    "bg": "#1C7A73",
    "fg": "#F2D55C",
    "edge": "#0B3C39",
    "material": "stone",
    "pattern": "scales",
    "motif": "pyramid"
  },
  {
    "id": "skaven",
    "name": "Skaven",
    "bg": "#4B5B2B",
    "fg": "#D7CF9B",
    "edge": "#202711",
    "material": "stone",
    "pattern": "gnawed",
    "motif": "claw"
  },
  {
    "id": "orcs-goblins",
    "name": "Orcs & Goblins",
    "bg": "#41691E",
    "fg": "#E5D37A",
    "edge": "#182809",
    "material": "stone",
    "pattern": "rough",
    "motif": "tusks"
  },
  {
    "id": "vampire-counts",
    "name": "Vampire Counts",
    "bg": "#430B18",
    "fg": "#D8D0C6",
    "edge": "#150309",
    "material": "velvet",
    "pattern": "marble",
    "motif": "bat"
  },
  {
    "id": "tomb-kings",
    "name": "Tomb Kings of Khemri",
    "bg": "#C7A35A",
    "fg": "#193A4B",
    "edge": "#6B5120",
    "material": "stone",
    "pattern": "sand",
    "motif": "scarab"
  },
  {
    "id": "warriors-chaos",
    "name": "Warriors of Chaos",
    "bg": "#171717",
    "fg": "#B38A45",
    "edge": "#050505",
    "material": "metal",
    "pattern": "chaos",
    "motif": "star"
  },
  {
    "id": "beastmen",
    "name": "Beastmen Brayherds",
    "bg": "#5A3C24",
    "fg": "#D5C0A0",
    "edge": "#24170D",
    "material": "wood",
    "pattern": "fur",
    "motif": "horns"
  },
  {
    "id": "norsca",
    "name": "Norsca",
    "bg": "#405562",
    "fg": "#D5E4E7",
    "edge": "#152025",
    "material": "metal",
    "pattern": "runes",
    "motif": "ship"
  },
  {
    "id": "chaos-dwarfs",
    "name": "Chaos Dwarfs",
    "bg": "#2A1B18",
    "fg": "#E06B32",
    "edge": "#0B0706",
    "material": "metal",
    "pattern": "forge",
    "motif": "bull"
  },
  {
    "id": "ogre-kingdoms",
    "name": "Ogre Kingdoms",
    "bg": "#6B5845",
    "fg": "#EEE0B8",
    "edge": "#2A211A",
    "material": "stone",
    "pattern": "hide",
    "motif": "cleaver"
  },
  {
    "id": "grand-cathay",
    "name": "Grand Cathay",
    "bg": "#0F5B50",
    "fg": "#E6C45A",
    "edge": "#082B26",
    "material": "pristine",
    "pattern": "cloud",
    "motif": "dragon"
  },
  {
    "id": "daemons-chaos",
    "name": "Daemons of Chaos",
    "bg": "#442B57",
    "fg": "#F0D8FF",
    "edge": "#160E1C",
    "material": "iridescent",
    "pattern": "warp",
    "motif": "eye"
  },
  {
    "id": "khorne",
    "name": "Khorne",
    "bg": "#7C1010",
    "fg": "#D0A04A",
    "edge": "#230505",
    "material": "metal",
    "pattern": "bloodiron",
    "motif": "axes"
  },
  {
    "id": "nurgle",
    "name": "Nurgle",
    "bg": "#65752F",
    "fg": "#D4D19A",
    "edge": "#293014",
    "material": "resin",
    "pattern": "pox",
    "motif": "fly"
  },
  {
    "id": "tzeentch",
    "name": "Tzeentch",
    "bg": "#2059A8",
    "fg": "#E9C75F",
    "edge": "#0D2444",
    "material": "iridescent",
    "pattern": "arcane",
    "motif": "flameeye"
  },
  {
    "id": "slaanesh",
    "name": "Slaanesh",
    "bg": "#7D3E79",
    "fg": "#F3D5E9",
    "edge": "#2B1329",
    "material": "velvet",
    "pattern": "silk",
    "motif": "serpent"
  }
];

function numericLabels(sides, emblemPath) {
  if (sides === 100) return ["10","20","30","40","50","60","70","80","90", emblemPath];
  const labels = Array.from({ length: sides }, (_, i) => String(i + 1));
  labels[sides - 1] = emblemPath;
  return labels;
}

function maxFaceBumps(sides, bumpPath) {
  const count = sides === 100 ? 10 : sides;
  const bumps = Array(count);
  bumps[count - 1] = bumpPath;
  return bumps;
}

Hooks.once("diceSoNiceReady", async (dice3d) => {
  if (!dice3d) return;

  const dsnVersion = game.modules.get("dice-so-nice")?.version ?? "unknown";
  if (dsnVersion !== "6.2.9") {
    console.warn(`[${MODULE_ID}] Built and verified against Dice So Nice! 6.2.9; detected ${dsnVersion}.`);
  }

  for (const faction of FACTIONS) {
    const systemId = `geofen-dice-${faction.id}`;
    const colorsetId = `geofen-dice-${faction.id}`;
    const emblem = `modules/${MODULE_ID}/assets/emblems/${faction.id}.png`;
    const emblemBump = `modules/${MODULE_ID}/assets/emblems/${faction.id}-bump.png`;
    const textureId = `geofen-texture-${faction.id}`;
    const texture = `modules/${MODULE_ID}/assets/textures/${faction.id}.png`;
    const textureBump = `modules/${MODULE_ID}/assets/textures/${faction.id}-bump.png`;

    // Legacy object-form system registration is retained by DsN v6 and is stable on 6.2.9.
    dice3d.addSystem({ id: systemId, name: `${CATEGORY} — ${faction.name}` }, false);

    // DsN requires custom textures to finish preloading before a colorset references them.
    try {
      await dice3d.addTexture(textureId, {
        name: `${CATEGORY} — ${faction.name}`,
        composite: "overlay",
        source: texture,
        bump: textureBump
      });
    } catch (error) {
      console.error(`[${MODULE_ID}] Failed to preload texture for ${faction.name}`, error);
      continue;
    }

    dice3d.addColorset({
      name: colorsetId,
      description: `${CATEGORY} — ${faction.name}`,
      category: CATEGORY,
      foreground: faction.fg,
      background: faction.bg,
      outline: faction.edge,
      edge: faction.edge,
      texture: textureId,
      material: faction.material,
      font: "Arial Black",
      visibility: "visible"
    });

    for (const sides of [2, 4, 6, 8, 10, 12, 20, 100]) {
      dice3d.addDicePreset({
        type: `d${sides}`,
        labels: numericLabels(sides, emblem),
        bumpMaps: maxFaceBumps(sides, emblemBump),
        colorset: colorsetId,
        system: systemId,
        font: "Arial Black"
      });
    }
  }

  console.info(`[${MODULE_ID}] Registered ${FACTIONS.length} faction dice systems for Dice So Nice! 6.2.9.`);
});
