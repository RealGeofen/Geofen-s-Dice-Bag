# Geofen's : Dice Bag

**Version:** 1.0.0  
**Target:** Foundry VTT 14.365 + Dice So Nice! 6.2.9

A system-agnostic collection of Warhammer Fantasy-inspired faction dice for Dice So Nice!. Each faction registers its own selectable **Dice Preset (Faces)** and matching **Theme**. The dice use Dice So Nice's native 3D polyhedra for reliable 6.2.9 physics, with original custom textures, bump detail, materials, edge colors, and a unique emblem on each die's maximum face.

## Included faction sets

- Empire of Man
- Kingdom of Bretonnia
- Kislev
- Dwarfen Mountain Holds
- High Elf Realms
- Wood Elf Realms
- Dark Elves
- Lizardmen
- Skaven
- Orcs & Goblins
- Vampire Counts
- Tomb Kings of Khemri
- Warriors of Chaos
- Beastmen Brayherds
- Norsca
- Chaos Dwarfs
- Ogre Kingdoms
- Grand Cathay
- Daemons of Chaos
- Khorne
- Nurgle
- Tzeentch
- Slaanesh

Each set covers d2, d4, d6, d8, d10, d12, d20, and percentile d100.

## Use

1. Install and enable **Dice So Nice! 6.2.9**.
2. Install and enable **Geofen's : Dice Bag**.
3. Open Dice So Nice settings.
4. Under **Dice Presets (Faces)** choose the desired `Geofen's : Dice Bag — <Faction>` entry.
5. The matching faction colorset is registered in the **Theme** list under `Geofen's : Dice Bag` as well.
6. Reload the world after first enabling the module if Dice So Nice was already initialized.

## Compatibility design

Version 1.0.0 intentionally targets Dice So Nice! **6.2.9** rather than relying on the custom physics-shape API added later. It keeps the native Dice So Nice colliders and 3D geometry so face results and landings remain consistent on the requested version.

## Distribution URLs

Manifest: `https://github.com/RealGeofen/geofen-s-dice-bag/releases/latest/download/module.json`

Download for v1.0.0: `https://github.com/RealGeofen/geofen-s-dice-bag/releases/download/v1.0.0/geofen-s-dice-bag-v1.0.0.zip`

## Fan project notice

This is an unofficial fan-made module. Warhammer and related faction names are trademarks/properties of their respective rights holders. The visual emblems and texture assets in this package are original artwork created for this module and do not reproduce official faction logos or commercial dice artwork.
